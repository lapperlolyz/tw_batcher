<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '1.3.4
Верхняя панель теперь плавающая
1.3.3
Массовые поиск-замена в ресурсах
1.3.2
Строки снова перерисовываются после массового обновления
1.3.1
Редактирование TV из таблицы
1.3.0
Редактирование полей из таблицы',
    'license' => false,
    'readme' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '56d2a45874a70e0332775934bb9fd15a',
      'native_key' => 'rebatcher',
      'filename' => 'modNamespace/994b3bf9d3da2eb0e00b83280df3335e.vehicle',
      'namespace' => 'rebatcher',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b52bf8024bad9b2b118b81b07f058296',
      'native_key' => 'rebatcher',
      'filename' => 'modMenu/6087c902f867654f75a32805841faab6.vehicle',
      'namespace' => 'rebatcher',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a4fd82652cb2c70435a287cb84f8b064',
      'native_key' => NULL,
      'filename' => 'modCategory/c5998cc0a1fd6b409c174c5118af9fba.vehicle',
      'namespace' => 'rebatcher',
    ),
  ),
);